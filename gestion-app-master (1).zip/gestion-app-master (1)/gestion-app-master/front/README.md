# React + Vite - Proyecto general

En este proyecto quiero mostrar ciertos conceptos de react a nivel general; así mimso, mostrar contenido de JavaScript
