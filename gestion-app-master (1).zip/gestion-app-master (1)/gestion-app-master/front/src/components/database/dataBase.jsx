export let usuarios = [
    {
        user: "admin",
        contrasena: "1234"
    },
    {
        user: 'jaime',
        contrasena: "1234" 
    },
    {
        user: 'santi',
        contrasena: "1234" 
    }
]