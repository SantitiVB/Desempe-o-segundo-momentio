import Header from "../../helpers/Header"

const Home = () => {
  return (
    <div>
        <Header />
    </div>
  )
}

export default Home